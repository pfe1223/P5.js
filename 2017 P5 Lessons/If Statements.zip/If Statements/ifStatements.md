#If Statements

Follow along with the video below to learn how to use if statements in your code.

<div style="position:relative;height:0;padding-bottom:56.25%"><iframe src="https://www.youtube.com/embed/1Osb_iGDdjk?list=PLRqwX-V7Uu6Zy51Q-x9tMWIv9cueOFTFA?ecver=2" width="640" height="360" frameborder="0" style="position:absolute;width:100%;height:100%;left:0" allowfullscreen></iframe></div>

<script type="text/p5" data-preview-width="500">




</script>

##Coding Challenge

<img src="circles4.gif" alt="Circle Gif">

Use your code from the previous coding challenge. Add a conditional statement that resets a circle's position when it goes off the canvas.

<script type="text/p5" data-preview-width="500">




</script>
